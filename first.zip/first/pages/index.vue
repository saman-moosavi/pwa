<template>
  <Tutorial/>
</template>

<script>
export default {}
</script>
